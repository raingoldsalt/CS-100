import random
import pygame

SCREEN_WIDTH = 400
SCREEN_HEIGHT = 600
FPS = 60
SCROLL = 200
GRAVITY = 1
MAX_PLATFORMS = 20
scroll = 0
bg_scroll = 0
score = 0
high_score = 0
game_over = False
ranNum = random.randint(1,6)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)


pygame.init()
Font = pygame.font.SysFont('Lucida Sans', 36)
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("2D Platformer")

clock = pygame.time.Clock()

bgi = pygame.image.load('dd.png').convert_alpha()
bgi = pygame.transform.scale(bgi, (400, 600))
blob = pygame.image.load('doodlejump.png').convert_alpha()
blob2 = pygame.image.load('doodlejump.png').convert_alpha()
up = pygame.image.load('faceup.png').convert_alpha()
wood = pygame.image.load('wood.png').convert_alpha()
mon1 = pygame.image.load('Monster_1-removebg-preview.png').convert_alpha()
mon2 = pygame.image.load('Monster_2-removebg-preview.png').convert_alpha()
mon3 = pygame.image.load('Monster_3-removebg-preview.png').convert_alpha()
mon4 = pygame.image.load('Monster_4-removebg-preview.png').convert_alpha()
mon5 = pygame.image.load('Monster_5-removebg-preview.png').convert_alpha()
mon6 = pygame.image.load('Monster_6-removebg-preview.png').convert_alpha()
bullet_img = pygame.image.load('circle.png').convert_alpha()

def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))

def background(bg_scroll):
    screen.blit(bgi, (0, 0 + bg_scroll))
    screen.blit(bgi, (0, -600 + bg_scroll))


class Player():
    def __init__(self, x, y):
        self.image = pygame.transform.scale(blob, (45,45))
        self.width = 25
        self.height = 40
        self.rect = pygame.Rect(0,0, self.width, self.height)
        self.rect.center = (x, y)
        self.velocity = 0
        self.flip = False
        self.shot = pygame.time.get_ticks()

    def move(self):
        scroll = 0
        dx = 0
        dy = 0
        cooldown = 500
        
        key = pygame.key.get_pressed()
        if key[pygame.K_a]:
            dx -= 10
            self.flip = True
            
        if key[pygame.K_d]:
            dx += 10
            self.flip = False
            
        time = pygame.time.get_ticks()
        
        if key[pygame.K_SPACE] and time - self.shot > cooldown:
            bullet = Bullets(self.rect.centerx, self.rect.top)
            bullet_group.add(bullet)
            self.shot = time
            self.image = pygame.transform.scale(up, (50,50))

        self.velocity += GRAVITY
        dy += self.velocity

        if self.rect.right < 0:
            self.rect.x = SCREEN_WIDTH
        elif self.rect.left > SCREEN_WIDTH:
            self.rect.x = -self.rect.width

        for platform in platforms:
            if platform.rect.colliderect(self.rect.x, self.rect.y+dy, self.width, self.height):
                if self.rect.bottom < platform.rect.centery:
                    if self.velocity > 0:
                        self.rect.bottom  = platform.rect.top
                        dy = 0
                        self.velocity = -20              
                        self.image = pygame.transform.scale(blob2, (45,45))

        if self.rect.top <= SCROLL:
            if self.velocity < 0:
                scroll = -dy

        self.rect.x += dx
        self.rect.y += dy + scroll

        return scroll

                

    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False), (self.rect.x - 12,
                                                                       self.rect.y - 5))

class Bullets(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(bullet_img, (10, 10))
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]

    def update(self):
        self.rect.y -= 20

class Monster(pygame.sprite.Sprite):
    def __init__(self, x, y, ranNum):
        pygame.sprite.Sprite.__init__(self)
        if(ranNum==1):
            self.image = pygame.transform.scale(mon1, (50,50))
        elif(ranNum==2):
            self.image = pygame.transform.scale(mon2, (50,50))
        elif(ranNum==3):
            self.image = pygame.transform.scale(mon3, (50,50))
        elif(ranNum==4):
            self.image = pygame.transform.scale(mon4, (50,50))
        elif(ranNum==5):
            self.image = pygame.transform.scale(mon5, (50,50))
        elif(ranNum==6):
            self.image = pygame.transform.scale(mon6, (50,50))
        self.width = 50
        self.height = 50
        self.rect = pygame.Rect(0,0, self.width, self.height)
        ranNum2 = random.randint(1,2)
        if(ranNum2==1):
            self.rect.center = (x-200, y-400)
        elif(ranNum2==2):
            self.rect.center = (x+200, y-400)
        self.direction = 0
        if(ranNum2==1):
            self.direction = +1
        elif(ranNum2==2):
            self.direction = -1


    def update(self, scroll, SCREEN_WIDTH):

        self.rect.x += self.direction * 2
        self.rect.y += scroll
        if self.rect.left <= 0:
           self.direction = +1
        elif self.rect.right >= SCREEN_WIDTH:
           self.direction = -1

        for bullet in bullet_group:
            if bullet.rect.colliderect(self.rect.x, self.rect.y, self.width, self.height):
                self.kill()

class Platform(pygame.sprite.Sprite):
    def __init__(self,x,y,width):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(wood,(width, 10))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self, scroll):

        self.rect.y += scroll

        if self.rect.top > SCREEN_HEIGHT:
            self.kill()


blob = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 150)
platforms = pygame.sprite.Group()
enemy_group = pygame.sprite.Group()
platform = Platform(SCREEN_WIDTH // 2 - 30, SCREEN_HEIGHT - 50, 100)
platforms.add(platform)
enemy = Monster(SCREEN_WIDTH // 2, SCREEN_HEIGHT-150, ranNum)
enemy_group.add(enemy)
bullet_group = pygame.sprite.Group()


run = True
while run:

    clock.tick(FPS)

    if game_over == False:
        scroll = blob.move()
        ranNum = random.randint(1,6)

        bg_scroll += scroll
        if bg_scroll >= 600:
            bg_scroll = 0
        background(bg_scroll)
        
        if len(platforms) < MAX_PLATFORMS:
            p = random.randint(40,60)
            px = random.randint(0, SCREEN_WIDTH - p)
            py = platform.rect.y - random.randint(80,120)
            platform = Platform(px,py,p)
            platforms.add(platform)
    
        platforms.update(scroll)
        bullet_group.update()
        
        if len(enemy_group) == 0:
            enemy = Monster(SCREEN_WIDTH // 2, 150, ranNum)
            enemy_group.add(enemy)
        
        enemy_group.update(scroll, SCREEN_WIDTH)
        
        platforms.draw(screen)
        blob.draw()
        enemy_group.draw(screen)
        bullet_group.draw(screen)

        if scroll > 0:
            score += scroll
        
        if blob.rect.top > SCREEN_HEIGHT:
            game_over = True
        
        if enemy.rect.top > SCREEN_HEIGHT:
            enemy.kill()
        
        if pygame.sprite.spritecollide(blob, enemy_group, False):
            if pygame.sprite.spritecollide(blob, enemy_group, False, pygame.sprite.collide_mask):
                game_over = True
        
        
        score_text = Font.render('Score: ' + str(int(score/10)), True, BLACK, WHITE)
        screen.blit(score_text, (280,30))
        high_score_text = Font.render('High Score: ' + str(int(high_score/10)), True, BLACK, WHITE)
        screen.blit(high_score_text, (220,0))
      
    else: 
        draw_text('GAME OVER!', Font, WHITE, 130, 200)
        draw_text('SCORE'+ str(int(score/10)), Font , WHITE, 130, 250)
        draw_text('PRESS TAB TO PLAY AGIAN', Font , WHITE, 40,300)

        key = pygame.key.get_pressed()
        if key[pygame.K_TAB]:
            game_over = False
            score = 0
            scroll = 0
            blob.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 150)
            platforms.empty()
            platform = Platform(SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT - 50, 100)
            platforms.add(platform)
            enemy_group.empty()
            enemy = Monster(SCREEN_WIDTH // 2, SCREEN_HEIGHT-150, ranNum)
            enemy_group.add(enemy)
  
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            
    if score > high_score:
        high_score = score  
    
    
    pygame.display.update()

pygame.quit()


